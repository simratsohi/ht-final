<?php
	include('header.php');
	$num1=$_POST['num'];
	$num2=$_POST['num1'];
	$num3=$_POST['num2'];
	
	$result= $num1 + $num2 + $num3;
	echo $result;
?>