<?php
	$num=$_POST['num']
?>
<html>
	<head>
	</head>
	<body>
		<?php include('header.php');?>
		<form action="math2.php" method="post">
			Number2: <input type="text" name="num1">
			<input type="hidden"  name="num"value="<?php echo $num; ?>">
			<input type="submit" name="submit" value="continue">
		</form>
	</body>
</html>