<?php
	include('connect.php');
?>
<html>
	<head>
	
	</head>
	<a href="view.php">view</a>
	// <form action="index.php" method="post" class="form-group">
		<h1>Registeration form</h1>
			Name:<input type="text" name="fname"><br><br>
			Last Name:<input type="text" name="lname"><br><br>
			Email:<input type="text" name="email"><br><br>
			
			<input type="submit" value="submit" name="submit">
		</form>
</html>
<?php
	if(isset($_POST['submit']))
	{
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$email=$_POST['email'];
		
	//insert the data into the database
	$sql="insert into mytable (fname,lname,email)
values('$fname','$lname','$email')";
		
	if ($conn->query($sql) === TRUE) {
			echo "<script>alert('New record created successfully')</script>";
			} else {
			echo "Error: " . $sql . "<br>" .
			$conn->error;
				}
	}
?>