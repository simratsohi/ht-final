<?php
$servername = "localhost";
$username = "root";
$password = "";
$mydb="students";

// Create connection
$conn = new mysqli($servername,$username,
$password,$mydb);

//check connection

if($conn->connect_error)
{
	die("Connection failed: " . $conn->connect_error);
}

?> 

