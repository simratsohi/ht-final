<html>
<body>
    <?php
    $x = 75;
    $y = 25;
    function addition() {
        $GLOBALS['z']=$GLOBALS['x'] + $GLOBALS['y'];
        //echo $x+$y;
    }
    addition();
    echo $z;
    
    ?>
</body>
</html>