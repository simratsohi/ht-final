<?php
$servername = "localhost";
$username = "root";
$password = "";
$mydb="students";
//create connection
$conn = new mysqli($servername,$username,$password,$mydb);
//check conection
if($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}
echo "connection established";
?>