<?php
	include('connect.php');
?>
<html>
<head></head>
	<body>
		<form action="connectindex.php" method="post">
			First Name<input type="text" name="fname">
			Last Name<input type="text" name="lname">
			Email<input type="text" name="email">
			
			<input type="submit" name="submit" value="submit">
		</form>
	</body>
</html>




<?php
	if(isset($_POST['submit']))
	{
			$fname=$_POST['fname'];
			$lname=$_POST['lname'];
			$email=$_POST['email'];
			
			//insert the data into database
			$sql="insert into mytable (fname,lname,email) values('$fname','$lname','$email')";
			if(mysqli_query($conn,$sql))
			{
				echo "recorded successfully";
			}
			else
			{
				echo "Error" . $sql . "<br>" .
				$conn->error;
			}
	}
?>		