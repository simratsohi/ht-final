<?php
    echo "hello"." ".$_POST['fname'];
?>