<?php
function maximun($x, $y){
if ($x,$y){
return $x;
}else{
return$y;
}}
$a=23;
$b=32;
$val = maximun($a,$b);
echo"the max of $a and $b is $val \n"
?>   