<html>
    <form action="display.php" method="post">
        Name <input type="text" name="fname"><br>
        <input type="submit" name="submit" value="submit">
    
    </form>
<body>
    <?php    
    /*$x = 75;
    $y = 25;
    function addition() {
        $GLOBALS['z']=$GLOBALS['x'] + $GLOBALS['y'];
        //echo $x+$y;
    }
    addition();
    echo $z;*/
    
    ?>
</body>
</html>